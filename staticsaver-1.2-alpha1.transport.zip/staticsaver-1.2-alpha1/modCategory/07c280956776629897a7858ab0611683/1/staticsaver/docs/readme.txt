--------------------
StaticSaver
--------------------
Version: 1.1.2-pl
Author: Vitaly Kireev <kireevvit@gmail.com>
--------------------

StaticSaver is a plugin for MODx Revolution that automatically sets up the name of file and media 
resource of element (template, chunk, snippet, TV or plugin) when wanting 
to make this element be static.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/argnist/StaticSaver/issues